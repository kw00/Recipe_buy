package food.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import food.model.food;
import food.model.foodDao;

@Controller
public class foodListController {

	private static final String command = "/list.fd";
	private static final String gotoPage = "foodList";
	
	@Autowired
	@Qualifier("MyFoodDao")
	foodDao dao;
	
	@RequestMapping(command)
	public String list(Model model){
		List<food> flists = dao.fSelectAll();
		model.addAttribute("flists", flists);
		return gotoPage;
	}
}
