package food.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import food.model.food;
import food.model.foodDao;



@Controller
public class foodInsertController {
	private static final String getPage = "foodInsertForm";
	private static final String gotoPage = "redirect:/list.fd";
	private static final String command = "/insert.fd";
	
	@Autowired
	@Qualifier("MyFoodDao")
	foodDao dao;
	
	@RequestMapping(value=command, method=RequestMethod.GET )
	public String doActionGet(){
		
		return getPage;
	}
	
	@RequestMapping(value=command, method=RequestMethod.POST )
	public ModelAndView doActionPost( @ModelAttribute("food") @Valid food bean, BindingResult result ){
		ModelAndView mav = new ModelAndView();
		if(result.hasErrors()){
			System.out.println("��ȿ�� �˻� �����Դϴ�.");
			mav.setViewName(getPage);
			return mav;
		}
		
		int cnt = -1;
		cnt = dao.Insertfood(bean);
		mav.setViewName(gotoPage);
		return mav;
	}
}
