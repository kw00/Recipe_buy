package food.model;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class food {
	private int fnum;
	@NotEmpty(message="��ǰ�� �̸��� �Է��ϼ���.")
	private String fname;
	@NotEmpty(message="��ǰ�� ī�װ����� �Է��ϼ���.")
	private String fcategory;
	private String fimage;
	@NotNull(message="������ �Է��ϼ���.")
	private int fqty;
	@NotNull(message="������ �Է��ϼ���.")
	private int fprice;
	private String fcontents;
	private String fcompany;
	private int fpoint;
	private String finputdate;

	public food() {
		super();
	}
	public food(int fnum, String fname, String fcategory, String fimage, int fqty, int fprice, String fcontents,
			String fcompany, int fpoint, String finputdate) {
		super();
		this.fnum = fnum;
		this.fname = fname;
		this.fcategory = fcategory;
		this.fimage = fimage;
		this.fqty = fqty;
		this.fprice = fprice;
		this.fcontents = fcontents;
		this.fcompany = fcompany;
		this.fpoint = fpoint;
		this.finputdate = finputdate;
	}

	public int getFnum() {
		return fnum;
	}
	public void setFnum(int fnum) {
		this.fnum = fnum;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getFcategory() {
		return fcategory;
	}
	public void setFcategory(String fcategory) {
		this.fcategory = fcategory;
	}
	public String getFimage() {
		return fimage;
	}
	public void setFimage(String fimage) {
		this.fimage = fimage;
	}
	public int getFqty() {
		return fqty;
	}
	public void setFqty(int fqty) {
		this.fqty = fqty;
	}
	public int getFprice() {
		return fprice;
	}
	public void setFprice(int fprice) {
		this.fprice = fprice;
	}
	public String getFcontents() {
		return fcontents;
	}
	public void setFcontents(String fcontents) {
		this.fcontents = fcontents;
	}
	public int getFpoint() {
		return fpoint;
	}
	public void setFpoint(int fpoint) {
		this.fpoint = fpoint;
	}
	public String getFinputdate() {
		return finputdate;
	}
	public void setFinputdate(String finputdate) {
		this.finputdate = finputdate;
	}
	public String getFcompany() {
		return fcompany;
	}
	public void setFcompany(String fcompany) {
		this.fcompany = fcompany;
	}
}
